window.onload = init;

var cant = 0;

function init() {
    var view = document.getElementById('view');
    var area = document.getElementById('area');

    view.onclick = edit;
    document.onkeydown = function (e) {
        e = e || event;
       
        if (e.keyCode == 27) {
            cancel();
            return false;
        }
        if ((e.ctrlKey && e.keyCode == 'E'.charCodeAt(0)) && !area.offsetHeight) {
            edit();
            return false;
        }
        if ((e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) && area.offsetHeight) {
            save();
            return false;
        }
    }
    function edit() {
        view.style.display = 'none';
        area.value = view.innerHTML;
        area.style.display = 'block';
        area.style.width = '444px';
        area.focus();
    }
    function save() {
        area.style.display = 'none';
        view.innerHTML = area.value;
        view.style.display = 'block';
        view.style.fontFamily ='Arial';
        view.style.fontSize ='30px'
    }
}

function precio(){
    cant = 0;
    var op = document.getElementById("super");
    if(op.checked == true){
        cant = cant + 7.25;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 7.25;
    }
}
function precio1(){
    cant = 0;
    var op = document.getElementById("personal");
    if(op.checked == true){
        cant = cant + 5.75;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant -5.75;
    }
}
function precio2(){
    cant = 0;
    var op = document.getElementById("infantil");
    if(op.checked == true){
        cant = cant + 3.50;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 3.50;
    }
}
function precio3(){
    var op = document.getElementById("ensalada");
    if(op.checked == true){
        cant = cant + 1.50;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.50;
    }
}
function precio4(){
    var op = document.getElementById("papas");
    if(op.checked == true){
        cant = cant + 1.25;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.25;
    }
}
function precio5(){
    var op = document.getElementById("pollog");
    if(op.checked == true){
        cant = cant + 1.75;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.75;
    }
}
function precio6(){
    var op = document.getElementById("pollom");
    if(op.checked == true){
        cant = cant + 1.50;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.50;
    }
}
function precio7(){
    var op = document.getElementById("pollop");
    if(op.checked == true){
        cant = cant + 1.25;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.25;
    }
}
function precio8(){
    var op = document.getElementById("bebidag");
    if(op.checked == true){
        cant = cant + 1.50;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.50;
    }
}
function precio9(){
    var op = document.getElementById("bebidam");
    if(op.checked == true){
        cant = cant + 1.25;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.25;
    }
}
function precio10(){
    var op = document.getElementById("bebidap");
    if(op.checked == true){
        cant = cant + 1.00;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.00;
    }
}
function precio11(){
    var op = document.getElementById("cafe");
    if(op.checked == true){
        cant = cant + 0.50;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 0.50;
    }
}
function precio12(){
    var op = document.getElementById("postre");
    if(op.checked == true){
        cant = cant + 1.25;
        totalprecios.innerHTML = "<p>La cuenta total es:"+cant+"</p>" 
    }
    else{
        cant = cant - 1.25;
    }
}
function enviar(){
    document.getElementById("view").innerHTML;
    document.getElementById("totalprecios").innerHTML;
}