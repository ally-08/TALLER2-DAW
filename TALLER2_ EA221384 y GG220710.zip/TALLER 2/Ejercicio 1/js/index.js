var nombres = {
    "Personas": [
        {
            "imagen": "img/one piece.jpg",
            "nombre": "One Piece Red Film",
            "duracion de pelicula": "1 hora, 45 minutos ",
            "clasificacion": +12,
            "Tipo de butacas": "1° fila",
            "Horarios de presentacion": "Todas disponibles en crunchyroll"

        },
        {
            "imagen": "img/jjt.jpg",
            "nombre": "jujutsu 0",
            "duracion de pelicula": "1 hora, 45 minutos",
            "clasificacion": +12,
            "Tipo de butacas": "1° fila",
            "Horarios de presentacion": "Todas disponibles en crunchyroll"

        },
        {
            "imagen": "img/totoro.jpg",
            "nombre": "Mi vecino Totoro",
            "duracion de pelicula": "1 hora, 45 minutos",
            "clasificacion": +12,
            "Tipo de butacas": "1° fila",
            "Horarios de presentacion": "Todas disponibles en crunchyroll"  
        },
    
        
    ]
};
//Obteniendo el elemento contenedor donde se cargarán todos los datos del objeto JSON
var div = document.getElementById("info");
div.innerHTML = volcarDatos(nombres.Personas);
function volcarDatos(datos) {
    var total = datos.length;
    data = "<ul class=\"grid\">\n";
    for (var i = 0; i < total; i++) {
        data += "<li class=\"box\">\n";
        data += "<div class=\"box-shadow\"></div>\n";
        data += "<div class=\"box-gradient\">\n";
        data += "<img src=\"" + datos[i].imagen + "\" alt=\"Avatar de " +
        datos[i].Titulo + " " + datos[i].titulo + "\" class=\"img\" />\n";
        data += "<h4>\nTitulo: " + datos[i].nombre +  "\n</h4>\n";
        data += "<p>\Duracion pelicula:1 hora 45 minutos " +  "\n<br />\n";
        data += "Clasificacion: +12" +  "\n</p>\n";
        data += "Tipo de butacas: 1° fila " +  "\n</p>\n";
        data += "Horarios de presentacion: Todas disponibles en crunchyroll " +  "\n</p>\n";
        
    }
    data += "</ul>\n";
    return data;
}